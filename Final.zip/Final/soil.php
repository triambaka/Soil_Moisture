<html>

<body>
<div class="topnav">
        <a href="homepage.html" >Home</a>
        <a href="login.php">Login</a>
        <a href="signup.php">SignUp</a>
        <a href="homepage.html">Contact</a>
        <a href="#a1">About</a>
</div>
<div id="target" style="display:none;">
<?php
$file=fopen("confused.txt","r");
while(!feof($file))
{
    $string=fgets($file);
    //header('Location: content.php?username=' . $string .'');
    //echo " Your soil's moisture content is ". $string ."%";
    echo htmlspecialchars($string);

}
$page = $_SERVER['PHP_SELF'];
$sec = "4";
?>
</div>
<br><br><br>
<div id="aaa" style="display:block" style="align: center;"></div>
<div id="new" style="display:block"> </div>
<script>
var divv=document.getElementById("target");
var myd=divv.textContent;
var c=document.getElementById("aaa");
c.innerHTML="The moisture content of your soil is: "+myd+" %";
//document.body.style.backgroundImage = "url('crop.jpg')";
var con=document.getElementById("new");

if(myd<=20)
{
    con.innerHTML="Your soil is DRY,Irrigation might help";
    
}
if(myd>20 && myd<70 )
{
    con.innerHTML="CONGRATS!!!Your soil moisture is perfect"
}
if(myd>70)
{
    con.innerHTML="Soil is TOO moist"
}
</script> 

</body>
<head>
        <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
        <style>
            body{
            background-image:url("crop1.jpg");
            background-repeat: no-repeat;
            background-size: cover;
        }
        #aaa,#new{
            color:white;
            background-color: rgb(0,0,0,0.5);
            width:32%;
            height:2%;
            text-align: center;
            padding:30px;
            position:absolute;
            left:30%;
            top:10%;
            font-size:20px;
        }
        #new
        {
            top:20%;
        }
        html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }
        
        .topnav {
            overflow: hidden;
            background-color: #333;
        }
        
        .topnav a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 120px;
            text-decoration: none;
            font-size: 17px;
        }
        
        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }
        
        .topnav a.active {
            background-color: rgb(31, 185, 236);
            color: white;
        }
            </style>
</head>
</html>
