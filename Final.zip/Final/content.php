<html>
<head>
        <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
</head>
<body>
<div id="target" style="display:none;">
<?php
$file=fopen("confused.txt","r");
while(!feof($file))
{
    $string=fgets($file);
    //header('Location: content.php?username=' . $string .'');
    //echo " Your soil's moisture content is ". $string ."%";
    echo htmlspecialchars($string);

}
$page = $_SERVER['PHP_SELF'];
$sec = "4";
?>
</div>
<div id="aaa"></div>
<script>
var divv=document.getElementById("target");
var myd=divv.textContent;
var c=document.getElementById("aaa");
c.innerHTML=myd;

</script>    
</body>
</html>