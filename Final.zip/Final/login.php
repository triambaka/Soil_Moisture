<?php
    require 'config.php';
    session_start();
?>

<?php
$url='soil.php';
if(isset($_POST['login']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];

    $query=" select * from info WHERE username='$username' AND password='$password'";

    $query_run=mysqli_query($con,$query);
    if(mysqli_num_rows($query_run)>0)
    {
        //valid
        //session variable
        $_SESSION['username']=$username;
        header("location:$url");
    }
    else
    {
        //invalid
        echo ' <script type="text/javascript"> alert("Invalid credentials, please try again") </script>';
    }
    
}
?>

<html>
    <head>
        <title>Log In</title>
        <link rel="shortcut icon" href="favicon.ico">
        <style type="text/css">
            #login1{
                position:relative;
                top:200px;
                background-color:rgb(0,0,0,0.5);
                color:white;
                height:280px;
                width:400px;
                left:20px;
                border-radius:10px;
            }
            body{
                background-image:url('crop.jpg');
                background-attachment: fixed;
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover;
                height:100%;
                margin:0;
            }
            .topnav {
  overflow: hidden;
  background-color: #333;
  position:fixed;
  width:100%;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

#login2{
    background-color:paleturquoise;
    border:2px solid black;
    border-radius:5px;
    height:80x;
    width:100px;
    font-size:30px;
}

#login2:hover{
    background-color:rgb(221, 221, 233);
}
        </style>
    </head>
  <body>
  <div class="topnav">
        <img src="skillcollab.png" style="float:left;height:48px;width:1000px;"/>
    <a href="index.html">Home</a>
    <a href="contact.html">Contact</a>
    <a href="#">About</a>
    <a class="active">Login</a>

</div>  
    <div id="login1">
    <form action="login.php" method="post">
        <br/>
    <center><label style="font-family:Tahoma;font-size:20px;color:paleturquoise;">Username:</label><br><br/></center>
    <center><input name="username" type="text" required></br></br><br/></center>
    <center><label style="font-family:Tahoma;font-size:20px;color:paleturquoise;">Password:</label><br><br/></center>
    <center><input name="password" type="password" required></br><br/><br></center>
    <center><input id="login2" name="login" type="submit" id="login_btn" value="Login"></br></br></center>
    </form>
        </div>    
    </body>
</html>
