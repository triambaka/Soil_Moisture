<?php
    require 'config.php';
    session_start();
?>
<html>
    <head>
        <style>
            .some{margin-left:5%;
            color:white;
            font-size:30px;
            background-color:rgb(0,0,0,0.5);
           
            }
            body
            {
                background-image:url("crop1.jpg");
                background-repeat: no-repeat;
                background-size: cover;
            }
            


            </style>
</head>
<body>

    <div class="some">
<?php


    $loc= $_POST['location'];
    $servername = "localhost";
$username = "root";
$password = "";
$dbname = "farmer";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM crop WHERE '$loc'=states";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "State: " . $row["states"]. " <br> Crop: " . $row["crops"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();

?>
</div>
</body>
</html>
