
import serial
import time
ser=serial.Serial('COM3',9600)
for i in range(7):
    b=ser.readline()
    string_n=b.decode()
    string=string_n.rstrip()
    flt=float(string)
    print(flt)
    f=open(r"C:\xampp\htdocs\Soil\confused.txt","w")
    f.write(str(flt))
    f.close()
    #data.append(flt)
    time.sleep(5)
'''

'''
