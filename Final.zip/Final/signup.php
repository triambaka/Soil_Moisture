<?php
    require 'config.php';
	session_start();
?>

<?php
$url='login.php';
    if(isset($_POST['submit_btn']))
    {
        //echo ' <script type="text/javascript"> alert("signup button clicked") </script>';
        $username=$_POST['username'];
        $mailid=$_POST['mailid'];
        $password=$_POST['password'];
        $cpassword=$_POST['cpassword'];
        if($password==$cpassword)
        {
            $query=" select * from info WHERE username='$username'";
            $query_run=mysqli_query($con,$query);
            if(mysqli_num_rows($query_run)>0)
            {
                //there is already user wih same username
                echo ' <script type="text/javascript"> alert("User already exists, try another username") </script>';
            }
            else
            {
                $query="insert into info values('$username','$mailid','$password')";
                $query_run=mysqli_query($con,$query);
                if($query_run)
                {
                    $_SESSION['username']=$username;
                    header("location:$url");
                }
                else
                {
                    echo ' <script type="text/javascript"> alert("Error, please try again later") </script>';
                }
            }
        }
        else
        {
            echo ' <script type="text/javascript"> alert("Password and confirm password does not match, try again") </script>';

        }
    }
?>

<html>
    <head>
        <title>Sign Up</title>
        <link rel="shortcut icon" href="favicon.ico">
        <style type="text/css">
            #signup1{
                position:relative;
                top:120px;
                background-color:black;
                color:white;
                height:420px;
                width:400px;
                left:20px;
                border-radius:10px;
            }
            body{
                background-image:linear-gradient(rgba(0, 0, 0, .5), rgba(0, 0, 0, .5)), url('https://images.unsplash.com/photo-1559884743-74a57598c6c7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1055&q=80');
                background-attachment: fixed;
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover;
                height:100%;
                margin:0;
            }
            .topnav {
  overflow: hidden;
  background-color: #333;
  position:fixed;
  width:100%;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #4CAF50;
  color: white;
}

#signup2{
    background-color:paleturquoise;
    border:2px solid black;
    border-radius:5px;
    height:80x;
    width:120px;
    font-size:30px;
}

#signup2:hover{
    background-color:rgb(221, 221, 233);
}
        </style>
    </head>
  <body>
  <div class="topnav">
        <img src="skillcollab.png" style="float:left;height:48px;width:1000px;"/>
    <a href="index.html">Home</a>
    <a href="contact.html">Contact</a>
    <a href="#">About</a>
    <a href="login.php">Login</a>

</div>  
    <div id="signup1">
    <form action="signup.php" method="post">
<center><label style="font-family:Tahoma;font-size:20px;color:paleturquoise;">Username:</label><br><br></center>
<center><input name="username" type="text" required></br><br></center>
<center><label style="font-family:Tahoma;font-size:20px;color:paleturquoise;">Mail-id:</label><br><br></center>
<center><input name="mailid" type="email" required></br><br></center>
<center><label style="font-family:Tahoma;font-size:20px;color:paleturquoise;">Password:</label><br><br></center>
<center><input name="password" type="password" required></br><br></center>
<center><label style="font-family:Tahoma;font-size:20px;color:paleturquoise;">Confirm Password:</label><br><br></center>
<center><input name="cpassword" type="password" required></br><br></center></br>
<center><input id="signup2" name="submit_btn" type="submit" id="signup_btn" value="Sign Up"></br></br></center></br>
</form>
    </body>
</html>
